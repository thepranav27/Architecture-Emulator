#include <assert.h>
#include "STRB_IMM_UOFF_32.h"
#include "../machine.h"

extern machine_t guest;

// Main: C6.2.276 STRB (immediate), unsigned offset variant
void decode_STRB_IMM_UOFF_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void execute_STRB_IMM_UOFF_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void memory_STRB_IMM_UOFF_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void wback_STRB_IMM_UOFF_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void update_pc_STRB_IMM_UOFF_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}