#include <assert.h>
#include "LDR_IMM_UOFF_64.h"
#include "../machine.h"

extern machine_t guest;

// Main: C6.2.131 LDR (immediate), unsigned offset variant
void decode_LDR_IMM_UOFF_64(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void execute_LDR_IMM_UOFF_64(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void memory_LDR_IMM_UOFF_64(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void wback_LDR_IMM_UOFF_64(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void update_pc_LDR_IMM_UOFF_64(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}