#ifndef _LDR_IMM_UOFF_64_H_
#define _LDR_IMM_UOFF_64_H_
#include <stdint.h>
#include "../instr.h"

extern void decode_LDR_IMM_UOFF_64(instr_t * const);
extern void execute_LDR_IMM_UOFF_64(instr_t * const);
extern void memory_LDR_IMM_UOFF_64(instr_t * const);
extern void wback_LDR_IMM_UOFF_64(instr_t * const);
extern void update_pc_LDR_IMM_UOFF_64(instr_t * const);
#endif