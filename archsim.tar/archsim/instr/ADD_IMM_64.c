#include <assert.h>
#include "ADD_IMM_64.h"
#include "../machine.h"

extern machine_t guest;

// Main: C6.2.4 ADD (immediate)
// Alias: C6.2.185 MOV (to/from SP)
void decode_ADD_IMM_64(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void execute_ADD_IMM_64(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void memory_ADD_IMM_64(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void wback_ADD_IMM_64(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void update_pc_ADD_IMM_64(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}