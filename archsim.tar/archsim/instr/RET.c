#include <assert.h>
#include "RET.h"
#include "../machine.h"

extern machine_t guest;

// Main: C6.2.219 RET
void decode_RET(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void execute_RET(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void memory_RET(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void wback_RET(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void update_pc_RET(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}