#include <assert.h>
#include "ADD_IMM_64.h"
#include "../machine.h"

extern machine_t guest;

// Main: C6.2.11 ADRP
void decode_ADRP(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void execute_ADRP(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void memory_ADRP(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void wback_ADRP(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void update_pc_ADRP(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}