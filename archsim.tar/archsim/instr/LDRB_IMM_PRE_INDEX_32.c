#include <assert.h>
#include "LDRB_IMM_PRE_INDEX_32.h"
#include "../machine.h"

extern machine_t guest;

// Main: C6.2.135 LDRB (immediate), pre-index variant
void decode_LDRB_IMM_PRE_INDEX_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void execute_LDRB_IMM_PRE_INDEX_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void memory_LDRB_IMM_PRE_INDEX_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void wback_LDRB_IMM_PRE_INDEX_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void update_pc_LDRB_IMM_PRE_INDEX_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}