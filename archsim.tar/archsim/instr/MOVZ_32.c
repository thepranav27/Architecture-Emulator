#include <assert.h>
#include "MOVZ_32.h"
#include "../machine.h"

extern machine_t guest;

// Main: C6.2.192 MOVZ
// Alias: C6.2.187 MOV (wide immediate)
void decode_MOVZ_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void execute_MOVZ_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void memory_MOVZ_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void wback_MOVZ_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void update_pc_MOVZ_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}