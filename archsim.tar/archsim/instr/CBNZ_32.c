#include <assert.h>
#include "CBNZ_32.h"
#include "../machine.h"

extern machine_t guest;

// Main: C6.2.44 CBNZ
void decode_CBNZ_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void execute_CBNZ_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void memory_CBNZ_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void wback_CBNZ_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}

void update_pc_CBNZ_32(instr_t * const insn) {
    // (STUDENT TODO)
    return;
}