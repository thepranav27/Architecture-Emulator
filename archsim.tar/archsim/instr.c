#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <assert.h>
#include "err_handler.h"
#include "instr.h"
#include "machine.h"
#include "instructions.h"

extern machine_t guest;

/*
 * Fetch.
 */

void fetch_instr(instr_t *const insn) {
    insn->insnbits = mem_read_I(guest.proc->PC.bits->xval);
    return;
}

/*
 * Decode and read operands: Level 0.
 * Lower levels are in the instr/ subdirectory.
 */

void decode_instr(instr_t * const insn) {
    int32_t instr = insn->insnbits;
    // bits 28:25 (C4.1)
    unsigned char op0 = EXTRACT(instr, 0x1E000000U, 25);

    switch (op0) {
        case 0: MISSING(); break;
        case 1: break;
        case 2: MISSING(); break;
        case 3: break;
        case 8: case 9: decode_DPI(insn); break;
        case 10: case 11: decode_B_EG_SYS(insn); break;
        case 4: case 6: case 12: case 14: decode_LD_ST(insn); break;
        case 5: case 13: MISSING(); break;
        case 7: case 15: MISSING(); break;
        default: assert(false); break;
    }
    return;
}

/*
 * Execute.
 */

void execute_instr(instr_t *const insn) {
    switch(insn->op) {
        case OP_ADD:    execute_ADD_IMM_64(insn); break;
        case OP_ADRP:   execute_ADRP(insn); break;
        case OP_MOV: 
        case OP_MOVZ:   execute_MOVZ_32(insn); break;
        case OP_LDR:    execute_LDR_IMM_UOFF_64(insn); break;
        case OP_STRB:   execute_STRB_IMM_UOFF_32(insn); break;
        case OP_LDRB:   execute_LDRB_IMM_PRE_INDEX_32(insn); break;
        case OP_CBNZ:   execute_CBNZ_32(insn); break;
        case OP_RET:    execute_RET(insn); break;
        case OP_NONE:
        case OP_ERROR:  assert(false); break;
    }
}

/*
 * Access memory.
 */

void memory_instr(instr_t *const insn) {
    switch(insn->op) {
        case OP_ADD:    memory_ADD_IMM_64(insn); break;
        case OP_ADRP:   memory_ADRP(insn); break;
        case OP_MOV: 
        case OP_MOVZ:   memory_MOVZ_32(insn); break;
        case OP_LDR:    memory_LDR_IMM_UOFF_64(insn); break;
        case OP_STRB:   memory_STRB_IMM_UOFF_32(insn); break;
        case OP_LDRB:   memory_LDRB_IMM_PRE_INDEX_32(insn); break;
        case OP_CBNZ:   memory_CBNZ_32(insn); break;
        case OP_RET:    memory_RET(insn); break;
        case OP_NONE:
        case OP_ERROR:  assert(false); break;
    }
}

/*
 * Write back to register file.
 */

void wback_instr(instr_t *const insn) {
    switch(insn->op) {
        case OP_ADD:    wback_ADD_IMM_64(insn); break;
        case OP_ADRP:   wback_ADRP(insn); break;
        case OP_MOV: 
        case OP_MOVZ:   wback_MOVZ_32(insn); break;
        case OP_LDR:    wback_LDR_IMM_UOFF_64(insn); break;
        case OP_STRB:   wback_STRB_IMM_UOFF_32(insn); break;
        case OP_LDRB:   wback_LDRB_IMM_PRE_INDEX_32(insn); break;
        case OP_CBNZ:   wback_CBNZ_32(insn); break;
        case OP_RET:    wback_RET(insn); break;
        case OP_NONE:
        case OP_ERROR:  assert(false); break;
    }
}

/*
 * Update PC.
 */

void update_pc_instr(instr_t *const insn) {
    switch(insn->op) {
        case OP_ADD:    update_pc_ADD_IMM_64(insn); break;
        case OP_ADRP:   update_pc_ADRP(insn); break;
        case OP_MOV: 
        case OP_MOVZ:   update_pc_MOVZ_32(insn); break;
        case OP_LDR:    update_pc_LDR_IMM_UOFF_64(insn); break;
        case OP_STRB:   update_pc_STRB_IMM_UOFF_32(insn); break;
        case OP_LDRB:   update_pc_LDRB_IMM_PRE_INDEX_32(insn); break;
        case OP_CBNZ:   update_pc_CBNZ_32(insn); break;
        case OP_RET:    update_pc_RET(insn); break;
        case OP_NONE:
        case OP_ERROR:  assert(false); break;
    }
}

#ifdef DEBUG
static char *opcode_names[] = {
    "ERR ", "ADD ", "ADRP", "MOV ", "MOVZ", "LDR ", "STRB", "LDRB", "CBNZ", "RET "
};

static char *cond_names[] = {
    "EQ", "NE", "CS", "CC", "MI", "PL", "VS", "VC", 
    "HI", "LS", "GE", "LT", "GT", "LE", "AL", "NV"
};
#endif

void show_instr(const instr_t * insn, const proc_stage_t stage) {
#ifdef DEBUG
    switch (stage) {
        case S_FETCH:
            printf("F:[%08lX  %08X]\n", guest.proc->PC.bits->xval, insn->insnbits);
            break;
        case S_DECODE:
            printf("D:\t\t\t[%s\t%s\t%s\t%s\t%s\t%016lX\t%d\t%c\t%c]\n", 
                opcode_names[insn->op], 
                insn->cond ? cond_names[insn->cond] : "--",
                insn->dst ? insn->dst->name : "---",
                insn->src1 ? insn->src1->name : "---",
                insn->src2 ? insn->src2->name : "---",
                insn->imm, 
                insn->shift,
                insn->wback ? 'Y' : 'N',
                insn->postindex ? 'Y' : 'N');
            break;

        case S_EXECUTE: MISSING(); break;
        case S_MEMORY: MISSING(); break;
        case S_WBACK: MISSING(); break;
        case S_UPDATE_PC: MISSING(); break;
        default: assert(false); break;
    }
#endif
    return;
}