#ifndef _INSTRUCTIONS_H_
#define _INSTRUCTIONS_H

#undef REF

#ifdef REF
#include "instr-ref/common_decoder.h"
#include "instr-ref/ADD_IMM_64.h"
#include "instr-ref/ADRP.h"
#include "instr-ref/CBNZ_32.h"
#include "instr-ref/LDR_IMM_UOFF_64.h"
#include "instr-ref/LDRB_IMM_PRE_INDEX_32.h"
#include "instr-ref/MOVZ_32.h"
#include "instr-ref/RET.h"
#include "instr-ref/STRB_IMM_UOFF_32.h"
#else
#include "instr/common_decoder.h"
#include "instr/ADD_IMM_64.h"
#include "instr/ADRP.h"
#include "instr/CBNZ_32.h"
#include "instr/LDR_IMM_UOFF_64.h"
#include "instr/LDRB_IMM_PRE_INDEX_32.h"
#include "instr/MOVZ_32.h"
#include "instr/RET.h"
#include "instr/STRB_IMM_UOFF_32.h"
#endif
#endif